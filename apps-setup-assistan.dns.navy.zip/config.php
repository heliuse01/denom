<?php

$config['apikey'] = 'UPv4FuFexruXBwuqymOLVDHtANnvGQXqwu7xNpATFCubx';  // https://killbot.org/dashboard/developers