<?php
require_once('../../../autoload.php');
$Killbot->error('self_403');